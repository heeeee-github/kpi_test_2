from django.apps import AppConfig


class EasyThumbnailsTestConfig(AppConfig):
    name = 'easy_thumbnails.tests'
    label = 'easy_thumbnails_tests'
