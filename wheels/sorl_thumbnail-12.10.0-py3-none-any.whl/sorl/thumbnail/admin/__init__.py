from django.forms import ClearableFileInput
from .current import AdminImageMixin

AdminInlineImageMixin = AdminImageMixin # backwards compatibility
