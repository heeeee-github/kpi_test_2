Take a look at https://github.com/jazzband/sorl-thumbnail/graphs/contributors
